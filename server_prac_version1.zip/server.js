const express = require('express')
const app = express()
const {MongoClient, ObjectId} = require('mongodb')
const methodOverride = require('method-override')   //서버에서 PUT DELETE요청위해 methodOverride 사용
const bcrypt = require('bcrypt')
const MongoStore = require('connect-mongo')         //세션을 메모리말고 db에 저장하려면
require('dotenv').config()                          //환경변수들을 따로 .env 파일에 보관함

const { S3Client } = require('@aws-sdk/client-s3')  // @aws-sdk/client-s3 AWS s3 사용시 필요
const multer = require('multer')                    // multer 유저가 보낸 파일 다루기 쉬워지는 라이브러리
const multerS3 = require('multer-s3')               // multer-s3 s3에 업로드 도와주는 라이브러리
const s3 = new S3Client({                             
  region : 'us-west-1',
  credentials : {
      accessKeyId : process.env.S3_KEY,
      secretAccessKey : process.env.S3_SECRET
  }
})

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'lincolncaforum1',
    key: function (req, file, cb) {
      cb(null, Date.now().toString()) //업로드시 파일명 변경가능 겹치면 안되기떄문에 현재시간으로 업로드되게함
    }
  })
})

app.use(methodOverride('_method'))                 //여기까지 methodOverride
app.use(express.static(__dirname + '/public'))    //public폴더참조를 위한 세팅
app.set('view engine', 'ejs')                     //ejs 세팅 html에다가 db데이터 꽂아주는 html 템플릿. 근데 확장자가 ejs임 views 폴더안에 넣는게 국룰
app.use(express.json())                           //res.body 쓰려면 이거랑,    body-parser에서 온것들
app.use(express.urlencoded({extended:true}))      //이거 필요

const session = require('express-session')        //로그인 form 만들어주는 라이브러리
const passport = require('passport')              //회원등록기능 라이브러리
const LocalStrategy = require('passport-local')   //회원 로그인기능 라이브러리
const connectDB = require('./database.js')

app.use(passport.initialize())                    //app.use끼리 순서 중요..
app.use(session({                                 //login 접속시 로그인페이지 보여주기
  secret: process.env.SECRET,                      //환경변수 중요!!! 세션 document id는 암호화해서 유저에게 보냄 절대 털리면 안됨  !!!중요
  resave : false,                                 //유저가 서버로 요청할때마다 세션 갱신할건지 보통 false가 일반적
  saveUninitialized : false,                      //로그인 안해도 세션 만들건지
  cookie : { maxAge : 60*60*1000},             //ms단위로 로그인세션 기간정함
  store: MongoStore.create({                      //서버가 재시작돼도 세션유지시켜주는 라이브러리 (session을 db에 저장해버림)
    mongoUrl: process.env.DB_URL,                 //환경변수 클라우드에 서버 배포할때 따로 env 파일을 만들어 보관하는게 나음
    dbName: 'forum'
  })
}))

app.use(passport.session())

// app.use(ask_login) API 100개에 미들웨어 전부 적용하고싶을때 현재 이 줄아래 있는 모든 API에는 현재 ask_login함수의 미들웨어 적용을 받는다
// app.use('/URL', ask_login) 해당 URL에만 해당 함수를 미들웨어로 적용가능하기도 함 /URL 하위 URL 전부에도 적용하기때문에 잘 쓰지않음 

// 혹은 이런식으로 /list API들마다 현재시간을 콘솔로 띄워주는 미들웨어도 만들수있음
// app.use('/list', (req, res, next){
//   console.log(new Date())
// })


let db;
connectDB.then((client)=>{
  console.log('DB연결 성공')
  db = client.db('forum');                   //forum이라는 이름의 Database에 접속 (RDB의 하위개념 Schema와는 어떤관계인지모르나 대충 비슷하다고 생각..)
  app.listen(process.env.PORT, function(){               //포트번호도 환경변수에 속함 .env에서 끌어올땐 process.env.변수명 방식으로 사용
    console.log('http://localhost:8080 에서 서버 실행중');
  });
}).catch((err)=>{
  console.log(err)
})

function ask_login(req, res, next){
  if(!req.user) {
    return res.send("<script>alert('로그인하세요'); window.location.replace('/login');</script>")
  }
  next()
}

function ask_logout(req, res, next){
  if(req.user) {
    return res.send("<script>alert('로그아웃해주세요'); history.back();</script>")
  }
  next()
}

//Home 접속시
app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
})

//home/write 접속시 미들웨어 ask_login 추가 미들웨어 함수는 여러개 들어갈 수 있고, 순서대로 실행 후 마지막 중괄호 안의 내용을 실행한다
app.get('/write', ask_login, (req, res) => {
  if(req.session.passport === undefined) res.render('write.ejs', {singed: 0})
  else if(req.session.passport) res.render('write.ejs', {signed: 1})
})

///write 페이지의 HTML에서 name="img1" 이름을 가진 이미지가 들어오면 S3에 자동 업로드해줌
//업로드 완료시 이미지의 URL도 생성해주는데 req.file안에 들어있음
//이미지 여러장 업로드할 경우 HTML input file에서 multiple 속성만 추가할게 아니라 upload.single이 아닌 upload.array로 바꿔야함
app.post('/addedRows', ask_login, async(req,res)=>{  
  upload.single('img1')(req, res, (err)=> {
    if(err) return res.send('업로드에러')
    try{                                       //try 안에 코드 실행해보고
      if(req.body.title==""){
        res.send('제목 똑바로 입력안하냐? 쪼그려뛰기 준비');
      }
      else if(req.body.content==""){
        res.send('내용 똑바로 입력안하냐?');
      }
      else {
        db.collection('post').insertOne({title: req.body.title, content: req.body.content,
          img: req.file.location, time: new Date()}) //db insert 문법 post라는 컬렉션(RDB에선 Table)에 접속
        res.redirect('/list/1');                 //페이지 네비게잇     
      }
    } catch (e) {                              //에러났으면 catch 코드 실행해봐
      console.log(e);                          //어떤 이유로 에러가 났는지 확인
      res.status(500).send('서버에러남');
    }
  })  
})

//home/list접속시
//코드 스탠다드: mongodb에선 db에서 데이터를 가져온다음 다음 줄의 코드들이 실행되는것을 동기화 시키고 싶을때 async await를 강제함 .then()을 좋아하지않음
app.get('/list', async(req, res) => {
  try{
    let rowCount = await db.collection('post').count()
    let result = await db.collection('post')
    .find().toArray()                     //Collection의 모든 documents를 출력하는 코드. await은 express 정책에 따라 정해진곳에서만 사용가능..
                                          //받아오는 document들은 array 타입으로 받아옴 result[0] 첫번째값, result[1] 두번째값...
    //console.log(result)                 //res.send나 res.sendFile, res.render 요청은 한번만 쓸수있음.. 맨위에것만 실행되고 나머지는 무시됨
    if(result == null || rowCount == 0) {
      res.redirect('/list/1')
    }
  } catch (e) { 
    console.log(e)
    res.status(404).send('현재 페이지에 게시글 없음')
  }
  
  res.render('list.ejs', {글목록: result, 글수: rowCount})                        //ejs 파일은 res.render 라고 써야됨 send나 sendFile 안됨
})                                                                //view 폴더안에 넣는게 국룰이었기때문에 폴더경로를 /views/list.ejs라고 안해도 됨

app.get('/list/:page', async(req, res) => {                       //URL 파라미터 이용
  //1~5번글까지 찾아 result 변수에 저장
  try {
    let rowCount = await db.collection('post').count()
    let result = await db.collection('post')
    .find().sort({time: -1}).skip((req.params.page-1) * 10)                           //.find({_id: {$gt: new ObjectId(req.params.page}}) 이런식이면 '다음'버튼밖에 못만듬
    .limit(10).toArray()                                             //.limit(5).toArray()
    
    if(result == null || rowCount == 0) {
      res.send('게시판 글 없음')
    }
    else {
      if(req.session.passport === undefined) res.render('list.ejs', {글목록: result, 글수: rowCount, signed: 0})
      else if(req.session.passport) res.render('list.ejs', {글목록: result, 글수: rowCount, signed: 1})
      console.log(req.session.passport)
    }    
  } catch (e) {
    console.log(e)
    res.status(404).send('존재하지 않는 페이지')
  }  
})

app.get('/detail/:id', async (req, res)=>{
  // console.log(req.params);
  try{
    let result = await db.collection('post').findOne({_id : new ObjectId(req.params.id)})
    if(result == null) {
      res.status(404).send('db에 없는 데이터')
    }
    else {
      if(req.session.passport === undefined) res.render('detail.ejs', {row:result, signed: 0})
        else if(req.session.passport) res.render('detail.ejs', {row:result, signed: 1}) 
    }
  }
  catch (e) {
    console.log(e)
    res.status(404).send('존재하지않는 페이지')
  }    
})

app.get('/edit/:id', ask_login, async(req,res)=>{
  let result = await db.collection('post').findOne({_id : new ObjectId(req.params.id)})
  if(req.session.passport === undefined) res.render('edit.ejs', {data:result, signed: 0})
    else if(req.session.passport) res.render('edit.ejs', {data:result, signed: 1})
})

app.put('/edit', upload.single('img1'), async(req,res)=>{           //RESTful 포맷에 따라 methodOverride로 POST요청에서 PUT요청으로 바꿈
  try{                                       //try 안에 코드 실행해보고
    if(req.body.title==""){
      res.send('제목 똑바로 입력안하냐? 쪼그려뛰기 준비');
    }
    else if(req.body.content==""){
      res.send('내용 똑바로 입력안하냐?');
    }
    else {
      await db.collection('post').updateOne(
        {_id: new ObjectId(req.body._id)}, 
        {
          $set: {title: req.body.title, content: req.body.content, img: req.file.location}
        }
      )                                     //db insert 문법 post라는 컬렉션(RDB에선 Table)에 접속
      console.log(req.body, req.file);
      res.redirect('/list/1');                 //페이지 네비게잇   
    }
  } catch (e) {                              //에러났으면 catch 코드 실행해봐
    console.log(e);                          //어떤 이유로 에러가 났는지 확인
    res.status(500).send('서버에러남');
  }
})

app.delete('/delete', async (req, res) => {
  await db.collection('post').deleteOne({_id : new ObjectId(req.query.docId)})
  //console.log(req.query.docId)               //Query String으로 작성해서 보내온 데이터이기때문에 req.body나 req.params가 아닌 req.query로 꺼내쓴다
  //res.redirect('list')                      //ajax는 새로고침하지않는 장점인데 이따구로 navigate하면 안됨 어차피 적용 안되거든..
  res.json();                                 //이거 안쓰면 ajax 삭제 바로적용 안됨
})

app.delete('/deleteOnDetail/', ask_login, async (req, res) => {
  console.log(req.body._id)
  await db.collection('post').deleteOne({_id: new ObjectId(req.body._id)})
  res.redirect('list/1');
})

app.get('/news', (req, res) =>{
  res.send('오늘 비 안옴')
})


//제출한 ID/비번 검사하는 코드 적는곳
passport.use(new LocalStrategy(async (inputUsername, inputPassword, cb) => {
  try{
    let result = await db.collection('user').findOne({ username : inputUsername})
    if (!result) {   //cb(1, 2, 3) 2에 false를 넣으면 로그인에 실패했다고 알려주는거
      return cb(null, false, { message: '가입되지 않은 아이디입니다' })
    }

    
    if (await bcrypt.compare(inputPassword, result.password)) {     //bcrypt 기능으로 db에 저장된 비번과 유저가 입력한 비번과 비교
      return cb(null, result) //로그인성공시 result를 보여줌
    } else {
      return cb(null, false, { message: '틀린 비밀번호입니다' });
    }
  } catch (e) {
    console.log(e)
    res.status(503).send('로그인실패')
  }  
}))
//이제 passport.authenticate('local')() 쓰면 위 함수가 실행됨

passport.serializeUser((user, done) => {
  process.nextTick(() => {                    //내부 코드를 비동기적으로 처리해줌 queueMicroTask()와 비슷하다고함
    done(null, {id: user._id, username: user.username})      //아래 req.logIn() 할때마다 세션 document에 기록되며 쿠키도 자동으로 만들어줌
  })
})

passport.deserializeUser(async (user, done) => {    
  let result = await db.collection('user').findOne({_id: new ObjectId(user.id)})  //최신 유저정보를 갱신하기위해 db에서 추가적으로 id 조회 하지만 이렇게되면 비번까지 가져오게됨
  delete result.password                      //비번은 지워놔야함
  process.nextTick(() => {                    //쿠키까보는 역할하는 코드
    done(null, result)                        //쿠키가 이상이 없으면 현재 로그인된 유저정보 알려줌
  })                                          //이제 서버내에서 req.user하면 로그인된 유저정보 알려줌
})

//--------------------------------------------------------------------------------------
//위에서 passport 라이브러리를 이용한 기본적 login 함수세팅을 마치고나서 
//아래부터 login관련 api를 구현한다. 이 순서를 지키지 못하면 로그인 기능이 작동이 안될수도 있음
//---------------------------------------------------------------------------------------

app.get('/login', ask_logout, async (req,res)=>{
  if(req.session.passport === undefined) res.render('login.ejs', {signed: 0})
    else if(req.session.passport) res.render('login.ejs', {signed: 1})
})

app.post('/login', async (req,res, next)=>{
  passport.authenticate('local', (error, user, info)=>{
    if(error) return res.status(500).json(error)          //로그인과정 오류시
    // if(!user) return res.status(401).json(info.message)   //로그인 매칭 실패시 
    if(!user) return res.send("<script>alert('"+ info.message+"'); window.location.replace('/');</script>")
    req.logIn(user, (err)=>{                                 //로그인성공시
      if(err) {
        return next(err)
      }
      res.redirect('/')
    })
  })(req, res, next)  //비교작업 에러시 error에 들어옴, 비교작업이 성공적일때 user에 정보들어옴, ID/PW이 일치하지않는경우엔 info에 정보가 들어감
})

app.post('/logout', ask_login, (req, res, next) =>{
  req.logout((err) => {
    if (err) return next(err)
    console.log(req.session)
    res.redirect('/')
  })
})

// app.get('/edit/:id', async(req,res)=>{
//   let result = await db.collection('post').findOne({_id : new ObjectId(req.params.id)})
//   res.render('edit.ejs', {data: result})
// })

app.get('/account', ask_login, async (req, res) => {
  console.log(req.user)
  if(req.session.passport === undefined) res.render('account.ejs', {data:req.user, signed: 0})
    else if(req.session.passport) res.render('account.ejs', {data:req.user, signed: 1})
})

app.get('/register', ask_logout, async (req, res) => {
  if(req.session.passport === undefined) res.render('register.ejs', {signed: 0})
    else if(req.session.passport) res.render('register.ejs', {signed: 1})
})

app.post('/register', async (req, res) => {
  let hashed = await bcrypt.hash(req.body.password, 10)         //hashing 기능 ('문자', 몇번꼬아줄지)
  
  if (await db.collection('user').findOne({username: req.body.username})){
    return res.send("<script>alert('이미 가입된 유저입니다.');"
    + "window.location.replace('/register');</script>")
  } else if (req.body.username == "" || req.body.password == "") {
    return res.send("<script>alert('username과 password는 빈칸으로 쓸 수 없습니다.');" 
    + "window.location.replace('/register');</script>")
  } else {
    await db.collection('user').insertOne({
      username: req.body.username, 
      password: hashed})
    res.redirect('/')
  }  
})

//너무나도 많아진 api들을 분리해서 보관할때, 먼저 routes폴더를 따로만들고 안에 분류된 js서버파일을 만들고 아래와 같이 import한다
app.use('/shop', require('./routes/shop.js'))